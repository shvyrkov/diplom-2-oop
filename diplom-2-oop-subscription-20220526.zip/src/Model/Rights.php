<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Support\Facades\DB;

/**
 * 
 */
class Rights extends Model
{
    /**
     * Первичный ключ таблицы Rights.
     *
     * @var string
     */
    protected $primaryKey = 'id';
}

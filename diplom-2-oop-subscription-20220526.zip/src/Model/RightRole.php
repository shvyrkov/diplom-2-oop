<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Support\Facades\DB;

/**
 * 
 */
class RightRole extends Model
{
    /**
     * Первичный ключ таблицы RightRole.
     *
     * @var string
     */
    protected $primaryKey = 'id';
}

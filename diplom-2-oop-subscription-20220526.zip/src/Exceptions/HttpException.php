<?php
namespace App\Exceptions;

/**
* HttpException — базовый класс HTTP-исключений.
*/
class HttpException extends ApplicationException
{

}

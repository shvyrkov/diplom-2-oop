<?php
namespace App\Exceptions;

/**
* ApplicationException — базовый класс исключений приложения, которые мы будем перехватывать. Наследуется от встроенного в PHP класса исключения.
*/
class ApplicationException extends \Exception
{

}

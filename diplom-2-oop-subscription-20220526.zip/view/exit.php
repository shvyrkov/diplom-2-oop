<?php
include 'layout/header.php';
?>

<div class="container">
    <h3>Вы успешно вышли из аккаунта</h3>
</div>

<?php
include 'layout/footer.php';

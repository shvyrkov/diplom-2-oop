    <!-- <div class="container-fluid px-5-auto title">
        <hr>
      <footer class="Footer">
        <div class="SiteNameFooter">Библиотека<br>Фасилитатора</div>
        <div class="SitePodpisFooter">Методы, инструменты, технологии...</div>
      </footer>
    </div> -->
    
    <div class="container-fluid MenuLineDown" >
      <div class="bottom">
          &copy; <?=date('Y')?> e-mail: facilitators.library@yandex.ru
      </div>
    </div>

<!--     <br>
    <footer class="page-footer">
      <div class="container">
        <address class="page-footer__copyright">
          <br>&copy;
          © Все права защищены
        </address>
      </div>
    </footer> -->

<?php
include 'base/footer.php';

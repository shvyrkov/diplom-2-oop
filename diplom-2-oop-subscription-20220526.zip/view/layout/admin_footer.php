    <br>
    <footer class="page-footer">
      <div class="container-fluid AdminMenuLineDown" >
        <div class="bottom">
          &copy; <?=date('Y')?> Admin e-mail: facilitators.library@yandex.ru
        </div>
      </div>
    </footer>

<?php
include 'base/footer.php';

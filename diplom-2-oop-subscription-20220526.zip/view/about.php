<?php
include 'layout/header.php';
?>

<div class="container">
    <h1><?=$title ?></h1>
</div>

<?php
include 'layout/footer.php';

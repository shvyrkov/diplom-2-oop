<?php
use App\Model\Post;
use App\Model\Users;

include 'layout/header.php';
?>

<div class="container">
    <h1><?=$title ?></h1>
    <?php
    echo "<pre>";


    echo "</pre>";
    ?>
</div>

<?php
include 'layout/footer.php';

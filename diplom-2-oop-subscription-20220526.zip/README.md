# diplom-2-oop
Site-blog with CMS

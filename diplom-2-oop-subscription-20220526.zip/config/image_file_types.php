<?php
return ['image/jpeg', 'image/jpg', 'image/png']; // Допустимые типы файлов изображений для загрузки на сервер

<?php

return [
     'db' => [
         'mysql' => [
             'host' => 'localhost'
         ]
     ],
     'db1' => [
        'mysql1' => [
            'host1' => 'localhost1'
        ]
    ],
    'db2' => [
        'mysql2' => [
            'host2' => [
                'dop_host2' => 'localhost222'
            ]
        ]
    ]
];

<?php
// Параметры конфигурации: хост, имя пользователя, пароль, имя базы данных.

return [
    'driver' => 'mysql',
    'host' => 'localhost',
    'database' => 'diplom_2_oop',
    'username' => 'mysql',
    'password' => 'mysql',
    'charset' => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix' => '',
];